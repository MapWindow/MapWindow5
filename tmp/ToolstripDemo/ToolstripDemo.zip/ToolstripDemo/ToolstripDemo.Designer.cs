﻿namespace ToolstripDemo
{
  partial class ToolstripDemo
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ToolstripDemo));
      this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
      this.toolStripStandard = new System.Windows.Forms.ToolStrip();
      this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.printToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
      this.cutToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.copyToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.pasteToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.helpToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.toolStripContainer2 = new System.Windows.Forms.ToolStripContainer();
      this.toolStripZoom = new System.Windows.Forms.ToolStrip();
      this.toolStripButtonZoomIn = new System.Windows.Forms.ToolStripButton();
      this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
      this.toolStripEdit = new System.Windows.Forms.ToolStrip();
      this.toolStripButtonTable = new System.Windows.Forms.ToolStripButton();
      this.toolStripPan = new System.Windows.Forms.ToolStrip();
      this.toolStripButtonPan = new System.Windows.Forms.ToolStripButton();
      this.toolStripContainer1.SuspendLayout();
      this.toolStripStandard.SuspendLayout();
      this.toolStripContainer2.RightToolStripPanel.SuspendLayout();
      this.toolStripContainer2.TopToolStripPanel.SuspendLayout();
      this.toolStripContainer2.SuspendLayout();
      this.toolStripZoom.SuspendLayout();
      this.toolStripEdit.SuspendLayout();
      this.toolStripPan.SuspendLayout();
      this.SuspendLayout();
      // 
      // toolStripContainer1
      // 
      // 
      // toolStripContainer1.ContentPanel
      // 
      this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(528, 237);
      this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
      this.toolStripContainer1.Name = "toolStripContainer1";
      this.toolStripContainer1.Size = new System.Drawing.Size(528, 262);
      this.toolStripContainer1.TabIndex = 0;
      this.toolStripContainer1.Text = "toolStripContainer1";
      // 
      // toolStripStandard
      // 
      this.toolStripStandard.Dock = System.Windows.Forms.DockStyle.None;
      this.toolStripStandard.ImageScalingSize = new System.Drawing.Size(24, 24);
      this.toolStripStandard.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripButton,
            this.openToolStripButton,
            this.saveToolStripButton,
            this.printToolStripButton,
            this.toolStripSeparator,
            this.cutToolStripButton,
            this.copyToolStripButton,
            this.pasteToolStripButton,
            this.toolStripSeparator1,
            this.helpToolStripButton});
      this.toolStripStandard.Location = new System.Drawing.Point(3, 0);
      this.toolStripStandard.Name = "toolStripStandard";
      this.toolStripStandard.Size = new System.Drawing.Size(248, 31);
      this.toolStripStandard.TabIndex = 0;
      // 
      // newToolStripButton
      // 
      this.newToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.newToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripButton.Image")));
      this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.newToolStripButton.Name = "newToolStripButton";
      this.newToolStripButton.Size = new System.Drawing.Size(28, 28);
      this.newToolStripButton.Text = "&New";
      // 
      // openToolStripButton
      // 
      this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.openToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripButton.Image")));
      this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.openToolStripButton.Name = "openToolStripButton";
      this.openToolStripButton.Size = new System.Drawing.Size(28, 28);
      this.openToolStripButton.Text = "&Open";
      // 
      // saveToolStripButton
      // 
      this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.saveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripButton.Image")));
      this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.saveToolStripButton.Name = "saveToolStripButton";
      this.saveToolStripButton.Size = new System.Drawing.Size(28, 28);
      this.saveToolStripButton.Text = "&Save";
      // 
      // printToolStripButton
      // 
      this.printToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.printToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripButton.Image")));
      this.printToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.printToolStripButton.Name = "printToolStripButton";
      this.printToolStripButton.Size = new System.Drawing.Size(28, 28);
      this.printToolStripButton.Text = "&Print";
      // 
      // toolStripSeparator
      // 
      this.toolStripSeparator.Name = "toolStripSeparator";
      this.toolStripSeparator.Size = new System.Drawing.Size(6, 31);
      // 
      // cutToolStripButton
      // 
      this.cutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.cutToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripButton.Image")));
      this.cutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.cutToolStripButton.Name = "cutToolStripButton";
      this.cutToolStripButton.Size = new System.Drawing.Size(28, 28);
      this.cutToolStripButton.Text = "C&ut";
      // 
      // copyToolStripButton
      // 
      this.copyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.copyToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripButton.Image")));
      this.copyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.copyToolStripButton.Name = "copyToolStripButton";
      this.copyToolStripButton.Size = new System.Drawing.Size(28, 28);
      this.copyToolStripButton.Text = "&Copy";
      // 
      // pasteToolStripButton
      // 
      this.pasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.pasteToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripButton.Image")));
      this.pasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.pasteToolStripButton.Name = "pasteToolStripButton";
      this.pasteToolStripButton.Size = new System.Drawing.Size(28, 28);
      this.pasteToolStripButton.Text = "&Paste";
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
      // 
      // helpToolStripButton
      // 
      this.helpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.helpToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("helpToolStripButton.Image")));
      this.helpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.helpToolStripButton.Name = "helpToolStripButton";
      this.helpToolStripButton.Size = new System.Drawing.Size(28, 28);
      this.helpToolStripButton.Text = "He&lp";
      // 
      // toolStripContainer2
      // 
      // 
      // toolStripContainer2.ContentPanel
      // 
      this.toolStripContainer2.ContentPanel.Size = new System.Drawing.Size(499, 231);
      this.toolStripContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.toolStripContainer2.Location = new System.Drawing.Point(0, 0);
      this.toolStripContainer2.Name = "toolStripContainer2";
      // 
      // toolStripContainer2.RightToolStripPanel
      // 
      this.toolStripContainer2.RightToolStripPanel.Controls.Add(this.toolStripZoom);
      this.toolStripContainer2.Size = new System.Drawing.Size(528, 262);
      this.toolStripContainer2.TabIndex = 1;
      this.toolStripContainer2.Text = "toolStripContainer2";
      // 
      // toolStripContainer2.TopToolStripPanel
      // 
      this.toolStripContainer2.TopToolStripPanel.Controls.Add(this.toolStripStandard);
      this.toolStripContainer2.TopToolStripPanel.Controls.Add(this.toolStripEdit);
      this.toolStripContainer2.TopToolStripPanel.Controls.Add(this.toolStripPan);
      // 
      // toolStripZoom
      // 
      this.toolStripZoom.Dock = System.Windows.Forms.DockStyle.None;
      this.toolStripZoom.ImageScalingSize = new System.Drawing.Size(24, 24);
      this.toolStripZoom.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonZoomIn,
            this.toolStripButton1});
      this.toolStripZoom.Location = new System.Drawing.Point(0, 3);
      this.toolStripZoom.Name = "toolStripZoom";
      this.toolStripZoom.Size = new System.Drawing.Size(29, 73);
      this.toolStripZoom.TabIndex = 0;
      // 
      // toolStripButtonZoomIn
      // 
      this.toolStripButtonZoomIn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.toolStripButtonZoomIn.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonZoomIn.Image")));
      this.toolStripButtonZoomIn.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.toolStripButtonZoomIn.Name = "toolStripButtonZoomIn";
      this.toolStripButtonZoomIn.Size = new System.Drawing.Size(27, 28);
      this.toolStripButtonZoomIn.Text = "toolStripButton1";
      // 
      // toolStripButton1
      // 
      this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
      this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.toolStripButton1.Name = "toolStripButton1";
      this.toolStripButton1.Size = new System.Drawing.Size(27, 28);
      this.toolStripButton1.Text = "toolStripButton1";
      // 
      // toolStripEdit
      // 
      this.toolStripEdit.Dock = System.Windows.Forms.DockStyle.None;
      this.toolStripEdit.ImageScalingSize = new System.Drawing.Size(24, 24);
      this.toolStripEdit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonTable});
      this.toolStripEdit.Location = new System.Drawing.Point(291, 0);
      this.toolStripEdit.Name = "toolStripEdit";
      this.toolStripEdit.Size = new System.Drawing.Size(40, 31);
      this.toolStripEdit.TabIndex = 1;
      // 
      // toolStripButtonTable
      // 
      this.toolStripButtonTable.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.toolStripButtonTable.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonTable.Image")));
      this.toolStripButtonTable.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.toolStripButtonTable.Name = "toolStripButtonTable";
      this.toolStripButtonTable.Size = new System.Drawing.Size(28, 28);
      this.toolStripButtonTable.Text = "toolStripButton1";
      // 
      // toolStripPan
      // 
      this.toolStripPan.Dock = System.Windows.Forms.DockStyle.None;
      this.toolStripPan.ImageScalingSize = new System.Drawing.Size(24, 24);
      this.toolStripPan.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonPan});
      this.toolStripPan.Location = new System.Drawing.Point(251, 0);
      this.toolStripPan.Name = "toolStripPan";
      this.toolStripPan.Size = new System.Drawing.Size(40, 31);
      this.toolStripPan.TabIndex = 2;
      // 
      // toolStripButtonPan
      // 
      this.toolStripButtonPan.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.toolStripButtonPan.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonPan.Image")));
      this.toolStripButtonPan.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.toolStripButtonPan.Name = "toolStripButtonPan";
      this.toolStripButtonPan.Size = new System.Drawing.Size(28, 28);
      this.toolStripButtonPan.Text = "toolStripButton1";
      // 
      // ToolstripDemo
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(528, 262);
      this.Controls.Add(this.toolStripContainer2);
      this.Controls.Add(this.toolStripContainer1);
      this.Name = "ToolstripDemo";
      this.Text = "Toolstrip Demo";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ToolstripDemoFormClosing);
      this.toolStripContainer1.ResumeLayout(false);
      this.toolStripContainer1.PerformLayout();
      this.toolStripStandard.ResumeLayout(false);
      this.toolStripStandard.PerformLayout();
      this.toolStripContainer2.RightToolStripPanel.ResumeLayout(false);
      this.toolStripContainer2.RightToolStripPanel.PerformLayout();
      this.toolStripContainer2.TopToolStripPanel.ResumeLayout(false);
      this.toolStripContainer2.TopToolStripPanel.PerformLayout();
      this.toolStripContainer2.ResumeLayout(false);
      this.toolStripContainer2.PerformLayout();
      this.toolStripZoom.ResumeLayout(false);
      this.toolStripZoom.PerformLayout();
      this.toolStripEdit.ResumeLayout(false);
      this.toolStripEdit.PerformLayout();
      this.toolStripPan.ResumeLayout(false);
      this.toolStripPan.PerformLayout();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.ToolStripContainer toolStripContainer1;
    private System.Windows.Forms.ToolStrip toolStripStandard;
    private System.Windows.Forms.ToolStripButton newToolStripButton;
    private System.Windows.Forms.ToolStripButton openToolStripButton;
    private System.Windows.Forms.ToolStripButton saveToolStripButton;
    private System.Windows.Forms.ToolStripButton printToolStripButton;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
    private System.Windows.Forms.ToolStripButton cutToolStripButton;
    private System.Windows.Forms.ToolStripButton copyToolStripButton;
    private System.Windows.Forms.ToolStripButton pasteToolStripButton;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripButton helpToolStripButton;
    private System.Windows.Forms.ToolStripContainer toolStripContainer2;
    private System.Windows.Forms.ToolStrip toolStripZoom;
    private System.Windows.Forms.ToolStripButton toolStripButtonZoomIn;
    private System.Windows.Forms.ToolStripButton toolStripButton1;
    private System.Windows.Forms.ToolStrip toolStripEdit;
    private System.Windows.Forms.ToolStripButton toolStripButtonTable;
    private System.Windows.Forms.ToolStrip toolStripPan;
    private System.Windows.Forms.ToolStripButton toolStripButtonPan;
  }
}

