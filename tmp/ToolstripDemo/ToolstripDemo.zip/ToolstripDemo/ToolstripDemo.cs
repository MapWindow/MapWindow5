﻿namespace ToolstripDemo
{
  using System.Windows.Forms;

  public partial class ToolstripDemo : Form
  {
    private readonly string keyName;

    public ToolstripDemo()
    {
      InitializeComponent();
      this.keyName = Application.ProductName + this.Name + "xyz";
      ToolStripManager.LoadSettings(this, this.keyName);
    }

    private void ToolstripDemoFormClosing(object sender, FormClosingEventArgs e)
    {
      ToolStripManager.SaveSettings(this, this.keyName);
    }
  }
}
